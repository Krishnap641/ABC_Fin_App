from django.shortcuts import render,redirect
from django.contrib.auth.models import User
from .models import *
from django.contrib.auth.models import Group
from student.models import *
from django.utils import timezone
from student.models import StuExam_DB,StuResults_DB
from questions.questionpaper_models import QPForm
from questions.question_models import QForm
from django.utils import timezone
from django.contrib.auth.decorators import login_required

def has_group(user, group_name):
    group = Group.objects.get(name=group_name)
    return True if group in user.groups.all() else False

@login_required(login_url='faculty-login')
def view_exams_prof(request):
    prof = request.user
    prof_user = User.objects.get(username=prof)
    permissions = False
    if prof:
        permissions = has_group(prof,"Professor")
    if permissions:
        new_Form = ExamForm(prof_user)
        if request.method == 'POST' and permissions:
            form = ExamForm(prof_user,request.POST)
            if form.is_valid():
                exam = form.save(commit=False)
                exam.professor = prof
                exam.save()
                form.save_m2m()
                return redirect('view_exams')

        exams = Exam_Model.objects.filter(professor=prof)
        return render(request, 'exam/mainexam.html', {
            'exams': exams, 'examform': new_Form, 'prof': prof,
        })
    else:
        return redirect('view_exams_student')

@login_required(login_url='faculty-login')
def add_question_paper(request):
    prof = request.user
    prof_user = User.objects.get(username=prof)
    permissions = False
    if prof:
        permissions = has_group(prof,"Professor")
    if permissions:
        new_Form = QPForm(prof_user)
        if request.method == 'POST' and permissions:
            form = QPForm(prof_user,request.POST)
            if form.is_valid():
                exam = form.save(commit=False)
                exam.professor = prof_user
                exam.save()
                form.save_m2m()
                return redirect('faculty-add_question_paper')

        exams = Exam_Model.objects.filter(professor=prof)
        return render(request, 'exam/addquestionpaper.html', {
            'exams': exams, 'examform': new_Form, 'prof': prof,
        })
    else:
        return redirect('view_exams_student')

@login_required(login_url='faculty-login')
def add_questions(request):
    prof = request.user
    prof_user = User.objects.get(username=prof)
    permissions = False
    if prof:
        permissions = has_group(prof,"Professor")
    if permissions:
        new_Form = QForm()
        if request.method == 'POST' and permissions:
            form = QForm(request.POST)
            if form.is_valid():
                exam = form.save(commit=False)
                exam.professor = prof_user
                exam.save()
                form.save_m2m()
                return redirect('faculty-addquestions')

        exams = Exam_Model.objects.filter(professor=prof)
        return render(request, 'exam/addquestions.html', {
            'exams': exams, 'examform': new_Form, 'prof': prof,
        })
    else:
        return redirect('view_exams_student')

@login_required(login_url='faculty-login')
def view_previousexams_prof(request):
    prof = request.user
    student = 0
    exams = Exam_Model.objects.filter(professor=prof)
    return render(request, 'exam/previousexam.html', {
        'exams': exams,'prof': prof
    })

@login_required(login_url='login')
def student_view_previous(request):
    exams = Exam_Model.objects.all()
    list_of_completed = []
    list_un = []
    for exam in exams:
        if StuExam_DB.objects.filter(examname=exam.name ,student=request.user).exists():
            if StuExam_DB.objects.get(examname=exam.name,student=request.user).completed == 1:
                list_of_completed.append(exam)
        else:
            list_un.append(exam)

    return render(request,'exam/previousstudent.html',{
        'exams':list_un,
        'completed':list_of_completed
    })

@login_required(login_url='faculty-login')
def view_students_prof(request):
    students = User.objects.filter(groups__name = "Student")
    student_name = []
    student_completed = []
    count = 0
    dicts = {}
    examn = Exam_Model.objects.filter(professor=request.user)
    for student in students:
        student_name.append(student.username)
        count = 0
        for exam in examn:
            if StuExam_DB.objects.filter(student=student,examname=exam.name,completed=1).exists():
                count += 1
            else:
                count += 0
        student_completed.append(count)
    i = 0
    for x in student_name:
        dicts[x] = student_completed[i]
        i+=1
    return render(request, 'exam/viewstudents.html', {
        'students':dicts
    })

@login_required(login_url='faculty-login')
def view_results_prof(request):
    students = User.objects.filter(groups__name = "Student")
    dicts = {}
    prof = request.user
    professor = User.objects.get(username=prof.username)
    examn = Exam_Model.objects.filter(professor=professor)
    for exam in examn:
        if StuExam_DB.objects.filter(examname=exam.name,completed=1).exists():
            students_filter = StuExam_DB.objects.filter(examname=exam.name,completed=1)
            for student in students_filter:
                key = str(student.student) + " " + str(student.examname) + " " + str(student.qpaper.qPaperTitle)
                dicts[key] = student.score
    return render(request, 'exam/resultsstudent.html', {
        'students':dicts
    })

@login_required(login_url='login')
def view_exams_student(request):
    exams = Exam_Model.objects.all()
    list_of_completed = []
    list_un = []
    for exam in exams:
        if StuExam_DB.objects.filter(examname=exam.name ,student=request.user).exists():
            if StuExam_DB.objects.get(examname=exam.name,student=request.user).completed == 1:
                list_of_completed.append(exam)
        else:
            list_un.append(exam)

    return render(request,'exam/mainexamstudent.html',{
        'exams':list_un,
        'completed':list_of_completed
    }) 

@login_required(login_url='login')
def view_students_attendance(request):
    exams = Exam_Model.objects.all()
    list_of_completed = []
    list_un = []
    for exam in exams:
        if StuExam_DB.objects.filter(examname=exam.name ,student=request.user).exists():
            if StuExam_DB.objects.get(examname=exam.name,student=request.user).completed == 1:
                list_of_completed.append(exam)
        else:
            list_un.append(exam)

    return render(request,'exam/attendance.html',{
        'exams':list_un,
        'completed':list_of_completed
    })

def convert(seconds): 
    min, sec = divmod(seconds, 60) 
    hour, min = divmod(min, 60) 
    min += hour*60
    return "%02d:%02d" % (min, sec) 

from random import shuffle

@login_required(login_url='login')
def appear_exam(request,id):
    student = request.user
    if request.method == 'GET':
        exam = Exam_Model.objects.get(pk=id)
        time_delta = exam.end_time - exam.start_time
        time = convert(time_delta.seconds)
        time = time.split(":")
        mins = time[0]
        secs = time[1]
        question_list = list(exam.question_paper.questions.all())
        shuffle(question_list)
        context = {
            "exam":exam,
            "question_list": question_list,
            "secs":secs,
            "mins":mins
        }
        return render(request,'exam/giveExam.html',context)
    if request.method == 'POST' :
        student = User.objects.get(username=request.user.username)
        paper = request.POST['paper'] 

        timer_value = request.POST.get('timer')

        user_ip = request.POST.get('user_ip')

        examMain = Exam_Model.objects.get(name = paper)
        stuExam = StuExam_DB.objects.get_or_create(examname=paper, student=student,qpaper = examMain.question_paper)[0]

        stuExam.submitted_time = timer_value
        stuExam.userip = user_ip

        # Save the StuExam_DB instance
        stuExam.save()

        
        qPaper = examMain.question_paper
        stuExam.qpaper = qPaper
         
        qPaperQuestionsList = examMain.question_paper.questions.all()
        for ques in qPaperQuestionsList:
            student_question = Stu_Question(student=student,question=ques.question, optionA=ques.optionA, optionB=ques.optionB,optionC=ques.optionC, optionD=ques.optionD,
            answer=ques.answer)
            student_question.save()
            stuExam.questions.add(student_question)
            stuExam.save()

        stuExam.completed = 1
        stuExam.save()
        examQuestionsList = StuExam_DB.objects.filter(student=request.user,examname=paper,qpaper=examMain.question_paper,questions__student = request.user)[0]
        #examQuestionsList = stuExam.questions.all()
        examScore = 0
        list_i = examMain.question_paper.questions.all()
        queslist = examQuestionsList.questions.all()
        i = 0
        for j in range(list_i.count()):
            ques = queslist[j]
            max_m = list_i[i].max_marks
            ans = request.POST.get(ques.question, False)
            if not ans:
                ans = "E"
            ques.choice = ans
            ques.save()
            if ans.lower() == ques.answer.lower() or ans == ques.answer:
                examScore = examScore + max_m
            i+=1

        stuExam.score = examScore
        stuExam.save()

        #submitted_time = datetime.now().time()  # Get the current time
        #stuExam.submitted_time = submitted_time  # Save the submitted time to StuExam_DB
        #stuExam.save()

        #new_entry = StuExam_DB(submitted_time=timer_value)
        #new_entry.save()

        

        stu = StuExam_DB.objects.filter(student=request.user,examname=examMain.name)  
        results = StuResults_DB.objects.get_or_create(student=request.user)[0]
        results.exams.add(stu[0])
        results.save()
        return redirect('view_exams_student')

'''@login_required(login_url='login')
def result(request,id):
    student = request.user
    exam = Exam_Model.objects.get(pk=id)
    score = StuExam_DB.objects.get(student=student,examname=exam.name,qpaper=exam.question_paper).score
    return render(request,'exam/result.html',{'exam':exam,"score":score})'''


'''@login_required(login_url='login')
def result(request, id):
    student = request.user
    exam = Exam_Model.objects.get(pk=id)
    stu_exam = StuExam_DB.objects.get(student=student, examname=exam.name, qpaper=exam.question_paper)

    # Retrieve all questions and student's answers for the exam
    questions = exam.question_paper.questions.all()
    student_answers = stu_exam.questions.all()

    # Create a dictionary to store question-answer pairs for rendering
    question_answers = {}
    
    # Retrieve correct answers and compare them with the student's answers
    for question in questions:
        # Find the corresponding student's answer for each question
        student_answer = student_answers.filter(question=question).first()

        # Add the question, correct answer, and student's answer to the dictionary
        question_answers[question] = {
            'question': question,
            'correct_answer': question.answer,
            'student_answer': student_answer.choice if student_answer else 'Not attempted'
        }

    score = stu_exam.score

    return render(request, 'exam/result.html', {
        'exam': exam,
        'score': score,
        'question_answers': question_answers
    })'''

'''
from django.shortcuts import render, get_object_or_404
#from .models import Exam_Model, StuExam_DB

def result(request, id):
    student = request.user
    exam = get_object_or_404(Exam_Model, pk=id)
    stu_exam = get_object_or_404(StuExam_DB, student=student, examname=exam.name, qpaper=exam.question_paper)
    
    # Get all the questions attempted by the student in this exam
    attempted_questions = stu_exam.questions.all()
    
    # Create a dictionary to store information about each question
    question_info = []
    for question in attempted_questions:
        # Compare the selected choice by the student with the correct answer
        is_correct = (question.choice == question.answer)
        
        # Append information about the question, student's answer, and correctness
        question_info.append({
            'question': question,
            'student_answer': question.choice,
            'is_correct': is_correct
        })
    
    # Calculate the total score
    total_score = stu_exam.score
    
    return render(request, 'exam/result.html', {
        'exam': exam,
        'question_info': question_info,
        'total_score': total_score
    })

'''

from django.shortcuts import render, get_object_or_404
#from .models import Exam_Model, StuExam_DB

def result(request, id):
    student = request.user
    exam = get_object_or_404(Exam_Model, pk=id)
    stu_exam = get_object_or_404(StuExam_DB, student=student, examname=exam.name, qpaper=exam.question_paper)
    
    # Get all the questions attempted by the student in this exam
    attempted_questions = stu_exam.questions.all()
    
    # Create a list to store information about each question
    question_info = []
    for question in attempted_questions:
        # Compare the selected choice by the student with the correct answer
        is_correct = (question.choice == question.answer)
        
        # Store information about the question, student's answer, correctness, and option values
        question_data = {
            'question': question,
            'student_answer': question.choice,
            'is_correct': is_correct,
            'option_values': {
                'A': question.optionA,
                'B': question.optionB,
                'C': question.optionC,
                'D': question.optionD,
            }
        }
        question_info.append(question_data)
    
    # Calculate the total score
    total_score = stu_exam.score
    
    return render(request, 'exam/result.html', {
        'exam': exam,
        'question_info': question_info,
        'total_score': total_score
    })
