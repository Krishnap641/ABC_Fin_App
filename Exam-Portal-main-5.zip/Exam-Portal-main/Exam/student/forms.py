from django import forms
from .models import StudentInfo
from django.contrib.auth.models import User

class StudentForm(forms.ModelForm):
    
    class Meta():
        model = User
        fields = ['username', 'email', 'password',]
        widgets = {
            
            'password': forms.PasswordInput(attrs = {'id':'passwordfield','class':'form-control'}),
            'email' : forms.EmailInput(attrs = {'id':'emailfield','class':'form-control','required': True}),
            'username' : forms.TextInput(attrs = {'id':'usernamefield','class':'form-control'})   #University registration ID : 
            
        }
class StudentInfoForm(forms.ModelForm):
    class Meta:
        model = StudentInfo
        fields = [ 'Candidate_name','profile', 'university_Name', 'qualification',]
        widgets = {
            #'address': forms.Textarea(attrs={'class': 'form-control'}),
            #'stream': forms.TextInput(attrs={'class': 'form-control'}),
            'Candidate_name': forms.TextInput(attrs={'id': 'Candidate name', 'class': 'form-control','required': True}),
            'profile': forms.FileInput(attrs={'class': 'form-control'}),
            'university_Name': forms.TextInput(attrs={'id': 'University Name', 'class': 'form-control','required': True}),
            'qualification': forms.TextInput(attrs={'id': 'Qualification', 'class': 'form-control','required': True})
        }

'''class StudentForm1(forms.ModelForm):
    
    class Meta():
        model = StudentInfo
        fields = [ 'confirm_password']
        widgets = {
            
            'confirm_password': forms.PasswordInput(attrs = {'id':'passwordfield','class':'form-control'}),
             
            
        }
    def clean(self):
        cleaned_data = super().clean()
        password = cleaned_data.get('password')
        confirm_password = cleaned_data.get('confirm_password')

        if password and confirm_password and password != confirm_password:
            self.add_error('confirm_password', "Passwords do not match")
        
        return cleaned_data'''