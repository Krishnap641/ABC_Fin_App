from django.contrib import admin
from .models import *

#from django.contrib import admin
from .models import StudentInfo, Stu_Question, StuExam_DB, StuResults_DB
#from questions.models import  
@admin.register(StudentInfo)
class StudentInfoAdmin(admin.ModelAdmin):
    list_display = ('user', 'Candidate_name','qualification','university_Name')  # Customize displayed fields

@admin.register(Stu_Question)
class StuQuestionAdmin(admin.ModelAdmin):
    list_display = ('student', 'choice','question_info')  # Customize displayed fields

    def question_info(self, obj):
        return obj.question_with_choices()  # Method to display question with choices
    question_info.short_description = 'Question and Choices'  # Set the column header

@admin.register(StuExam_DB)
class StuExamDBAdmin(admin.ModelAdmin):
    list_display = ('student', 'score', 'userip')  # Customize displayed fields
    #def view_student_answers(self, obj):
        #return f'<a href="/admin/student/stu_question/?exam_id={obj.id}">View Answers</a>'

    #view_student_answers.allow_tags = True
    #view_student_answers.short_description = 'Student Answers'  # Set the column header
    
'''@admin.register(StuResults_DB)
class StuResultsDBAdmin(admin.ModelAdmin):
    list_display = ('student', 'display_exams')  # Customize displayed fields

    def display_exams(self, obj):
        return ", ".join([str(exam) for exam in obj.exams.all()])

    display_exams.short_description = 'Exams'''

