from django.contrib import admin
from .models import StudentInfo, Stu_Question, StuExam_DB, StuResults_DB
#from questions.models import  
@admin.register(StudentInfo)
class StudentInfoAdmin(admin.ModelAdmin):
    list_display = ('user', 'address', 'stream')  # Customize displayed fields

@admin.register(Stu_Question)
class StuQuestionAdmin(admin.ModelAdmin):
    list_display = ('student', 'choice')  # Customize displayed fields

@admin.register(StuExam_DB)
class StuExamDBAdmin(admin.ModelAdmin):
    list_display = ('student', 'examname', 'qpaper', 'score', 'completed')  # Customize displayed fields

@admin.register(StuResults_DB)
class StuResultsDBAdmin(admin.ModelAdmin):
    list_display = ('student', 'display_exams')  # Customize displayed fields

    def display_exams(self, obj):
        return ", ".join([str(exam) for exam in obj.exams.all()])

    display_exams.short_description = 'Exams'

